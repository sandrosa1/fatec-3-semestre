var cep = document.getElementById('cep');
var arraycep = []
lerBanco();

consultar.addEventListener("click", () => {
  var cepsconsultados = {
        
    cep: cep.value,
    logradouro: logradouro.value,
    complemento: complemento.value,
    bairro: bairro.value,
    localidade: localidade.value,
    UF: UF.value,
    ibge: ibge.value
  }

  console.log(cepsconsultados)

  fetch(`https://viacep.com.br/ws/${Cep.value}/json/`)
    .then(a => a.json())
    .then(json => {
      
      cep.value = json.cep
      logradouro.value = json.logradouro
      complemento.value = json.complemento
      bairro.value = json.bairro
      localidade.value = json.localidade
      UF.value = json.UF
      ibge.value = json.ibge
      cepsconsultados.cep = json.cep
      cepsconsultados.logradouro = json.logradouro
      cepsconsultados.complemento = json.complemento
      cepsconsultados.bairro = json.bairro
      cepsconsultados.localidade = json.localidade
      cepsconsultados.uf = json.uf
      cepsconsultados.ibge = json.ibge

      arraycep.push(cepsconsultados)
      bdcep = cep.value
      localStorage.setItem('bdcep', JSON.stringify(arrayCep))
      console.log(bdcep)
    })
})

function lerBanco() {
  if (localStorage.hasOwnProperty('bdcep')) {
    
    bdcep = JSON.parse(localStorage.getItem('bdcep'))
    bdcep.forEach(cep => {
      
      if (cep.cep == bdcep.value) {
        
        cep.value = cep.cep
        logradouro.value = cep.logradouro
        complemento.value = cep.complemento
        bairro.value = cep.bairro
        localidade.value = cep.localidade
        uf.value = cep.uf
        ibge.value = cep.ibge
      }
    })
}
}