/*
Aqui quando abrir a página, já vamos pedir que seja carregado os itens que estiverem no LocalStorage,quando 
a página for atualizada.
*/
CarregarItens()

//validação do botão enviar
gravar.addEventListener('click', GravarItens)


//validação do botão limpar
limpar.addEventListener('click', LimparCarrinho)


//limpa os itens do localStorage
function LimparCarrinho() {
    localStorage.clear()
    carrinho.value = ''
    itens.innerHTML = 0 // elemento HTML
    detalhes.innerHTML = 0 
}
//Não pode ser substituido o itens e sim verificar se tem algum, carregar e acrescentar o novo item.
function GravarItens() {
    let produtos = [];
/*
Para verificar se tem algum item no carrinho usaremos o hasOwnProperty que irá procurar dentro do LocalStorage 
se existe uma key chamda 'produtos', se exitir será carregado dentro do array criado anteriormente (let = produtos).
*/
    if (localStorage.hasOwnProperty('produtos')) {
/* 
-Para carregar usamos um objeto nativo do JS, o JSON junto com o método parse esse método recebe uma string que 
estará gravado no LocalStorage, covertendo-o em um objeto JS.
-Para ler o LocalStorage usamos o getItem passando a chave que queremos ler ('produtos').
*/
    produtos = JSON.parse(localStorage.getItem('produtos'))
    }   
/* 
Aqui criamos um objeto baseado nos id dos inputs(descrição, qtde e valor)
*/     
     produto ={
         descricao: descricao.value,
         qtde: qtde.value,
         valor:(qtde.value * valor.value)     
    }
/*
-Aqui vamos juntar tudo e convertenr o objeto em string e gravar no LocalStorage:
-Usaremos o push para inserir mais um item no array de produtos e como argumento temos que usar o que queremos inserir 
que no caso é (produto).
-Iremos colocar isso tudo dentro do LocalStorage usando o setItem, o primeiro argumento é aqui o 'produtos' que queremos
gravar e o segundo argumento é o valor que queremos gravar, porém não é aceito um objeto JS, só aceita string, para isso 
faremos a conversão.
-O mesmo objeto que foi usado para converter em objeto será usada para converter em string.
- Usamos o JSON.stringify e como parâmetro usamos o nome do objeto/array que queremos converter em string.
- Isso será cnvertido e gravado dentro da key 'produtos'.
*/
    produtos.push(produto)
    localStorage.setItem('produtos', JSON.stringify(produtos))
    CarregarItens()
/*
-Depois que gravar o iten, pedimos que recarregue os itens.
-Ele irá limpar o textarea e adicionar todos os itens com tudo gravado no LocalStorage.
*/
    descricao.value = ''
    qtde.value = ''
    valor.value = ''
}
//função CarregarItens é para percorrer o array, ler e carregar os itens
function CarregarItens (){
    let produtos = []
    let valorTotal = 0
// strItens vai servir apenas para acumular as strings.
    let strItens = ''
    carrinho.value = ''

    if(localStorage.hasOwnProperty('produtos')){
       produtos = JSON.parse(localStorage.getItem('produtos'))
            produtos.forEach(produto => {
            valorTotal += produto.valor //+= soma ele mais ele mesmo
            strItens.value += 'Descrição: ' + produto.descricao +
                              'Quantidade: ' + produto.qtde + 
                              'Total: ' + produto.valor + '\n'
        })
        carrinho.value = strItens
    }
/*
-Total de itens do carrinho: como produtos foi criado com let e dentro do if, na hora de colocar 'produtos' depois 
do innerHTML, ele não será reconhecido, pois o let só é visto dentro do if.
-Portanto devemos fazer o seguinte: ao invés de criar o let dentro do if, vamos coloca-lo fora do if, desssa forma irá 
pertencer a toda função.
-Length = tamanho da variavél
*/
    itens.innerHTML = produtos.length
    detalhes.innerHTML = valorTotal
}
