//Tabela
function setList(list) {
    var table = '<thead><tr><td>Produto</td><td>Quantidade</td><td>Valor</td><td>Deletar Item</td></tr></thead><tbody>';
    for (var key in list) {
        table += '<tr><td>' + formatDesc(list[key].desc) + '</td><td>' + formatAmount(list[key].amount) + '</td><td>' + formatValue(list[key].value) + '</td><td><button class="btn btn-default" onclick="deleteData(' + key + ');">Delete</button></td></tr>';
    }
    table += '</tbody>';
    document.getElementById('listTable').innerHTML = table;
    getTotal(list);
    saveListStorage(list);
}
//Adiciona Produto
function addData() {
    if (!validation()) {
        return;
    }
    var desc = document.getElementById("desc").value;
    var amount = document.getElementById("amount").value;
    var value = document.getElementById("value").value;

    list.unshift({ "desc": desc, "amount": amount, "value": value });
    setList(list);
}

//Total
function getTotal(list) {
    var total = 0;
    for (var key in list) {
        total += list[key].value * list[key].amount;
    }
    document.getElementById("totalValue").innerHTML = formatValue(total);
}

//Deletar dados
function deleteData(id) {
    if (confirm("Tem certeza que deseja excluir este produto do carrinho?")) {
        if (id === list.length - 1) {
            list.pop();
        } else if (id === 0) {
            list.shift();
        } else {
            var arrAuxIni = list.slice(0, id);
            var arrAuxEnd = list.slice(id + 1);
            list = arrAuxIni.concat(arrAuxEnd);
        }
        setList(list);
    }
}

//Deleta Tudo
function deleteList() {
    if (confirm("Tem certeza que deseja excluir tudo?")) {
        list = [];
        setList(list);
    }
}

//Salvar no Storage
function saveListStorage(list) {
    var jsonStr = JSON.stringify(list);
    localStorage.setItem("list", jsonStr);
}

//Formata o nome do produto
function formatDesc(desc) {
    var str = desc.toLowerCase();
    str = str.charAt(0).toUpperCase() + str.slice(1);
    return str;
}

//Formata a quantidade
function formatAmount(amount) {
    return parseInt(amount);
}

//Formatação de preço para Real (R$)
function formatValue(value) {
    var str = parseFloat(value).toFixed(2) + "";
    str = str.replace(".", ",");
    str = "R$ " + str;
    return str;
}
//Erros e Validação
function validation() {
    var desc = document.getElementById("desc").value;
    var amount = document.getElementById("amount").value;
    var value = document.getElementById("value").value;
    var errors = "";
    document.getElementById("errors").style.display = "none";

    if (desc === "") {
        errors += '<p>Favor incluir um produto!</p>';
    }
    if (amount === "") {
        errors += '<p>Favor escolher a quantidade!</p>';
    } else if (amount != parseInt(amount)) {
        errors += '<p>Favor escolher uma quantidade válida!</p>';
    }
    if (value === "") {
        errors += '<p>Digite o valor do produto! </p>';
    } else if (value != parseFloat(value)) {
        errors += '<p>Valor inválido!</p>';
    }

    if (errors != "") {
        document.getElementById("errors").style.display = "block";
        document.getElementById("errors").innerHTML = "<h3>Algo não funcinou:</h3>" + errors;
        return 0;
    } else {
        return 1;
    }
}
//Teste
function initListStorage() {
    var testList = localStorage.getItem("list");
    if (testList) {
        list = JSON.parse(testList);
    }
    setList(list);
}
initListStorage();