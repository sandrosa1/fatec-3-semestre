var Cidade = document.getElementById('Cidade');
var Search = document.getElementById('Search');
var description = document.getElementById('description');
var divRoot = document.getElementById('root');
var div = document.createElement('div');

const basededados = 'https://api.hgbrasil.com';

function searchCity(city) {
  fetch(
    `${basededados}/stats/find_woeid?key=17284dd0&format=json-cors&sdk_version=console&city_name=${city}`
  )
    .then((res) => res.json())
    .then(({ woeid }) => {
      searchWeather(woeid);
      console.log(woeid);
    });
}

function searchWeather(woeid) {
  fetch(`${basededados}/weather/?format=json-cors&key=development&woeid=${woeid}`)
    .then((res) => res.json())
    .then(({ results }) => {
      render(results);
    });
}

function render(response) {
  divRoot.innerHTML = '';
  description.innerHTML = '';
  
  div.innerHTML = `
    <div class="info">
      <div class="temp">
        <h1>${response.city_name} - ${response.currently}</h1>
         <div>
          <strong>Temperatura atual: </strong>
          <span> ${response.temp} ºC </span>
        </div>
        <br>
        <div>
          <strong>Nascer do Sol: </strong>
          <span>${response.sunrise}</span> 
        </div>
        <br>
        <div>
          <strong>Pôr do Sol: </strong>
          <span>${response.sunset}</span> 
        </div>
        <br>
        <h3>${response.description}</h3>
      </div>
      <img src="http://assets.api.hgbrasil.com/weather/images/${response.img_id}.png" alt=""/>
    </div>
  `;

  description.appendChild(div);

  response.forecast.map((forecast) => {
    var divPrev = document.createElement('div');

    divPrev.innerHTML = `
    <div class="card">
      <h2>${forecast.date} - ${forecast.weekday}</h2>
      <div class="infoPrev">
        <div>
          <strong>Máxima: </strong> 
          <span>${forecast.max} ºC</span>
        </div>
        <div>
          <strong>Mínima: </strong> 
          <span>${forecast.min} ºC</span>
        </div>
      </div>
      <div class="descriptionPrev">
        ${forecast.description}
      </div>
    </div>
  `;

    divRoot.appendChild(divPrev);
  });
}

Search.addEventListener('click', () => {
  var city = Cidade.value;

  if (city === '') {
    alert('Insira a Cidade');
    return;
  }
  searchCity(city);
});
