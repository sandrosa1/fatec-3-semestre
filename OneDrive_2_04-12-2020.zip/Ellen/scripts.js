var btnPesquisar = document.getElementById('btnPesquisar');
var inputCity = document.getElementById('inputCity');
var divRoot = document.getElementById('root');
var description = document.getElementById('description');

const baseURL = 'https://api.hgbrasil.com';

function searchCity(city) {
  fetch(
    `${baseURL}/stats/find_woeid?key=17284dd0&format=json-cors&sdk_version=console&city_name=${city}`
  )
    .then((res) => res.json())
    .then(({ woeid }) => searchWeather(woeid));
}

function searchWeather(woeid) {
  fetch(`${baseURL}/weather/?format=json-cors&key=development&woeid=${woeid}`)
    .then((res) => res.json())
    .then(({ results }) => render(results));
}

searchCity('Campinas');

function render(response) {
  var div = document.createElement('div');

  div.innerHTML = `
    <div class="info">
      <h1>${response.city_name}</h1>
      <div class="temp">
        <div>
          <strong>Temperatura atual: </strong>
          <span> ${response.temp} ºC </span>
        </div>
        <div>
          <strong>Nascer do Sol: </strong>
          <span>${response.sunrise}</span> 
        </div>
        <div>
          <strong>Pôr do Sol: </strong>
          <span>${response.sunset}</span> 
        </div>
        <h3>${response.description}</h3>
      </div>
      <img src ="https://assets.hgbrasil.com/weather/images/${response.img_id}.png" alt= "imagens das mudanças climáticas">
    </div>
  `;

  description.appendChild(div);

  response.forecast.map((forecast) => {
    var divPrev = document.createElement('div');

    divPrev.innerHTML = `
    <div class="card">
      <h2>${forecast.date} - ${forecast.weekday}</h2>
      <div class="infoPrev">
        <div>
          <strong>Máxima: </strong> 
          <span>${forecast.max} ºC</span>
        </div>
        <div>
          <strong>Mínima: </strong> 
          <span>${forecast.min} ºC</span>
        </div>
      </div>
      <div class="descriptionPrev">
        ${forecast.description}
        ${forecast.condition}
      </div>
    </div>
  `;

    divRoot.appendChild(divPrev);
  });
}

btnPesquisar.addEventListener('click', () => {
  var city = inputCity.value;
  searchCity(city);
});
