var pesquisar = document.getElementById('pesquisar');
pesquisar.addEventListener('click', function() {
var cidade = document.getElementById('cidade').value;


var requerimento = new XMLHttpRequest();
    requerimento.open('GET', 'https://api.hgbrasil.com/weather/?format=json-cors&key=development&woeid=' + cidade);
    requerimento.send();
    requerimento.onload = function() {

    let jsonTexto = JSON.parse(requerimento.responseText);
    document.getElementById('exibircidade').innerHTML = 'Cidade: ' + jsonTexto.results.city;
    document.getElementById('date').innerHTML = 'Data: ' + jsonTexto.results.date;
    document.getElementById('time').innerHTML = 'Hora: ' + jsonTexto.results.time;
    document.getElementById('condições').innerHTML = 'Código da Condição Tempo Atual: ' +  jsonTexto.results.condition_code;
    document.getElementById('temperatura').innerHTML = 'Temperatura: ' + jsonTexto.results.temp + ' ºC | Umidade: ' + jsonTexto.results.humidity + ' %';
    document.getElementById('dianoite').innerHTML = 'Dia/Noite: ' + jsonTexto.results.currently;
    document.getElementById('humidade').innerHTML = 'Humidade: ' + jsonTexto.results.humidity;
    document.getElementById('ventos').innerHTML = 'Valocidade dos Ventos: ' + jsonTexto.results.wind_speedy;
    document.getElementById('nascerdosol').innerHTML = 'Nascer do Sol: ' + jsonTexto.results.sunrise;
    document.getElementById('pordosol').innerHTML = 'Por do Sol: ' + jsonTexto.results.sunset;
    document.getElementById('condicaoatual').innerHTML = 'Condições Atuais: ' + jsonTexto.results.condition_slug;
     img = jsonTexto.results.img_id;

     
        document.getElementById('imagem').src = 'http://assets.hgbrasil.com/weather/images/' + img + '.png';
        var texto = '';
        for (const previsao of jsonTexto.results.forecast) {
            texto += '<br>' + 'Dia:' + previsao.weekday +  ' ***  Data: ' + previsao.date + ' *** Previsão: ' + previsao.description + ' *** Temperaturas Minimas: ' + previsao.min + 'ºC'+ ' *** Temperaturas Maximas: ' + previsao.max + 'ºC' + '</br>';
        }
        document.getElementById('previsao').innerHTML = texto;
    }
});