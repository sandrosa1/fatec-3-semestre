consultar.addEventListener("click", () => {
  
  let cidade = document.getElementById('cidade');

    fetch(`https://api.hgbrasil.com/stats/find_woeid?key=17284dd0&format=json-cors&sdk_version=console&city_name=${cidade.value}`)
      .then(response => response.json())
      .then(codigo =>  fetch(`https://api.hgbrasil.com/weather/?format=json-cors&key=development&woeid=${codigo.woeid}`)
      .then(cidade => cidade.json()))
      .then(retorno => {
        document.querySelector('[resultado]').innerHTML =     
        `<h2> ${retorno.results.city} </h2>        
        <p>No momento é ${retorno.results.currently}</p>
        <p>Nascer do Sol às ${retorno.results.sunrise}</p>
        <p>Por do Sol às ${retorno.results.sunset}</p>
        <p>Temperatura de ${retorno.results.condition_code}°C e Umidade de ${retorno.results.humidity}%</p>
        <p>Situação: ${retorno.results.description}</p>`
        document.getElementById("imagem").src =`http://assets.api.hgbrasil.com/weather/images/${retorno.results.img_id}.png`;

        let proximosdias = retorno.results.forecast;
            let previsoes = "";
            proximosdias.forEach((days) => {
                previsoes +=`                
                <div class="card col" style="width: 18rem;">
                <div class="card-body">
                  <h5 class="card-title">Dia: ${days.date} ${days.weekday}</h5>
                  <h6 class="card-subtitle mb-2 text-muted">Mín de ${days.min}°C - Máx de ${days.max}°C</h6>
                  <p class="card-text">Previsão: ${days.description}</p>
                 </div> 
                </div>
                `;
            });

            proximos.innerHTML = previsoes;

        
      })

})