procurar.addEventListener('click', function (){
    let txtCidade = document.getElementById('cidade').value
    let codigoCidade = ''

    pesquisaCidade = 'https://api.hgbrasil.com/stats/find_woeid?key=17284dd0&format=json-cors&sdk_version=console&city_name=' + txtCidade

  fetch(pesquisaCidade)
    .then(response => response.json())
    .then(json => {
        codigoCidade = json.woeid
        
    })
    .catch(erro => console.error('ERRO: ' + erro))

    retornoPesquisa = 'https://api.hgbrasil.com/weather/?format=json-cors&key=development&woeid=' + codigoCidade
        fetch(retornoPesquisa)
            .then(response => response.json())
            .then(json =>{
                
               resultado.innerHTML =
                json.results.city_name + 
                ' | Temperatura: ' + json.results.temp + '°C | ' + json.results.description
                + '<br>' + 'HORÁRIO: ' + json.results.time + ' | DATA: ' + json.results.date
                + '<br>' + 'UMIDADE: ' + json.results.humidity + ' %'
               
            })
            .catch(erro => console.error('ERRO: ' + erro))


})

// não deu tempo de completar o restante